var loc = window.location;
var GB_ROOT_DIR = loc.protocol + '//' +  loc.host + "/static/greybox/";
